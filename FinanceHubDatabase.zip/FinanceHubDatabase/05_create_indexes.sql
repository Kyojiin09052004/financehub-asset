-- Create indexes for better performance

-- Assets table indexes
CREATE INDEX idx_assets_category ON assets(category_id);
CREATE INDEX idx_assets_location ON assets(location_id);
CREATE INDEX idx_assets_status ON assets(status);
CREATE INDEX idx_assets_purchase_date ON assets(purchase_date);
CREATE INDEX idx_assets_assigned_to ON assets(assigned_to);

-- Depreciation records indexes
CREATE INDEX idx_depreciation_asset ON depreciation_records(asset_id);
CREATE INDEX idx_depreciation_date ON depreciation_records(depreciation_date);

-- Asset maintenance indexes
CREATE INDEX idx_maintenance_asset ON asset_maintenance(asset_id);
CREATE INDEX idx_maintenance_date ON asset_maintenance(maintenance_date);
CREATE INDEX idx_maintenance_status ON asset_maintenance(status);

-- Asset transfers indexes
CREATE INDEX idx_transfers_asset ON asset_transfers(asset_id);
CREATE INDEX idx_transfers_date ON asset_transfers(transfer_date);
CREATE INDEX idx_transfers_status ON asset_transfers(status);

-- Journal entries indexes
CREATE INDEX idx_journal_date ON journal_entries(entry_date);
CREATE INDEX idx_journal_status ON journal_entries(status);

-- Journal entry lines indexes
CREATE INDEX idx_journal_lines_entry ON journal_entry_lines(journal_entry_id);
CREATE INDEX idx_journal_lines_account ON journal_entry_lines(account_id);

-- Users table indexes
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_department ON users(department);
CREATE INDEX idx_users_active ON users(is_active);
