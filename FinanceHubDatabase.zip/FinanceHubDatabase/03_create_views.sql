-- Create useful views for reporting and dashboard

-- Asset summary view
CREATE VIEW v_asset_summary AS
SELECT 
    ac.name AS category_name,
    COUNT(a.id) AS total_assets,
    SUM(a.original_cost) AS total_original_cost,
    SUM(a.current_value) AS total_current_value,
    SUM(a.accumulated_depreciation) AS total_depreciation,
    ROUND((SUM(a.accumulated_depreciation) / SUM(a.original_cost)) * 100, 2) AS depreciation_percentage
FROM assets a
JOIN asset_categories ac ON a.category_id = ac.id
WHERE a.status = 'active'
GROUP BY ac.id, ac.name;

-- Asset details view with location and category info
CREATE VIEW v_asset_details AS
SELECT 
    a.id,
    a.asset_id,
    a.name,
    a.description,
    ac.name AS category_name,
    l.name AS location_name,
    CONCAT(l.building, ' - ', l.floor, ' - ', l.room) AS full_location,
    a.purchase_date,
    a.original_cost,
    a.current_value,
    a.accumulated_depreciation,
    a.status,
    a.serial_number,
    a.model,
    a.manufacturer,
    CONCAT(u.first_name, ' ', u.last_name) AS assigned_to_name,
    DATEDIFF(CURDATE(), a.purchase_date) AS days_owned,
    ROUND(a.accumulated_depreciation / a.original_cost * 100, 2) AS depreciation_percentage
FROM assets a
LEFT JOIN asset_categories ac ON a.category_id = ac.id
LEFT JOIN locations l ON a.location_id = l.id
LEFT JOIN users u ON a.assigned_to = u.id;

-- Monthly depreciation schedule view
CREATE VIEW v_monthly_depreciation AS
SELECT 
    DATE_FORMAT(dr.depreciation_date, '%Y-%m') AS month_year,
    ac.name AS category_name,
    COUNT(DISTINCT dr.asset_id) AS assets_count,
    SUM(dr.depreciation_amount) AS total_depreciation,
    AVG(dr.depreciation_amount) AS avg_depreciation
FROM depreciation_records dr
JOIN assets a ON dr.asset_id = a.id
JOIN asset_categories ac ON a.category_id = ac.id
GROUP BY DATE_FORMAT(dr.depreciation_date, '%Y-%m'), ac.id, ac.name
ORDER BY month_year DESC, ac.name;

-- Asset maintenance summary view
CREATE VIEW v_maintenance_summary AS
SELECT 
    a.asset_id,
    a.name AS asset_name,
    ac.name AS category_name,
    COUNT(am.id) AS total_maintenance_records,
    SUM(am.cost) AS total_maintenance_cost,
    MAX(am.maintenance_date) AS last_maintenance_date,
    MIN(am.next_maintenance_date) AS next_maintenance_due
FROM assets a
LEFT JOIN asset_maintenance am ON a.id = am.asset_id
LEFT JOIN asset_categories ac ON a.category_id = ac.id
GROUP BY a.id, a.asset_id, a.name, ac.name;

-- Dashboard metrics view
CREATE VIEW v_dashboard_metrics AS
SELECT 
    (SELECT COUNT(*) FROM assets WHERE status = 'active') AS total_active_assets,
    (SELECT SUM(current_value) FROM assets WHERE status = 'active') AS total_asset_value,
    (SELECT SUM(accumulated_depreciation) FROM assets WHERE status = 'active') AS total_depreciation,
    (SELECT COUNT(DISTINCT category_id) FROM assets WHERE status = 'active') AS active_categories,
    (SELECT COUNT(*) FROM asset_maintenance WHERE status = 'scheduled' AND maintenance_date <= CURDATE() + INTERVAL 30 DAY) AS upcoming_maintenance;
