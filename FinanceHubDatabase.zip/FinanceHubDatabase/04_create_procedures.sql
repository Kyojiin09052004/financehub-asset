-- Stored procedures for common operations

DELIMITER //

-- Procedure to calculate and record monthly depreciation
CREATE PROCEDURE CalculateMonthlyDepreciation(IN target_date DATE)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE asset_id_var INT;
    DECLARE original_cost_var DECIMAL(12,2);
    DECLARE useful_life_var INT;
    DECLARE accumulated_dep_var DECIMAL(12,2);
    DECLARE monthly_dep_amount DECIMAL(12,2);
    DECLARE new_accumulated_dep DECIMAL(12,2);
    DECLARE new_book_value DECIMAL(12,2);
    
    DECLARE asset_cursor CURSOR FOR 
        SELECT id, original_cost, useful_life_years, accumulated_depreciation
        FROM assets 
        WHERE status = 'active' 
        AND purchase_date <= target_date;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN asset_cursor;
    
    read_loop: LOOP
        FETCH asset_cursor INTO asset_id_var, original_cost_var, useful_life_var, accumulated_dep_var;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Calculate monthly depreciation (straight line method)
        SET monthly_dep_amount = (original_cost_var * 0.9) / (useful_life_var * 12); -- 90% of cost over useful life
        SET new_accumulated_dep = accumulated_dep_var + monthly_dep_amount;
        SET new_book_value = original_cost_var - new_accumulated_dep;
        
        -- Ensure we don't depreciate below salvage value (10% of original cost)
        IF new_book_value < (original_cost_var * 0.1) THEN
            SET new_book_value = original_cost_var * 0.1;
            SET new_accumulated_dep = original_cost_var - new_book_value;
            SET monthly_dep_amount = new_accumulated_dep - accumulated_dep_var;
        END IF;
        
        -- Only record if there's depreciation to record
        IF monthly_dep_amount > 0 THEN
            -- Insert depreciation record
            INSERT INTO depreciation_records (
                asset_id, 
                depreciation_date, 
                depreciation_amount, 
                accumulated_depreciation, 
                book_value, 
                method_used, 
                created_by
            ) VALUES (
                asset_id_var, 
                target_date, 
                monthly_dep_amount, 
                new_accumulated_dep, 
                new_book_value, 
                'straight_line', 
                1
            );
            
            -- Update asset current value and accumulated depreciation
            UPDATE assets 
            SET current_value = new_book_value, 
                accumulated_depreciation = new_accumulated_dep,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = asset_id_var;
        END IF;
        
    END LOOP;
    
    CLOSE asset_cursor;
END //

-- Procedure to transfer an asset
CREATE PROCEDURE TransferAsset(
    IN p_asset_id INT,
    IN p_to_location_id INT,
    IN p_to_user_id INT,
    IN p_reason TEXT,
    IN p_created_by INT
)
BEGIN
    DECLARE current_location_id INT;
    DECLARE current_user_id INT;
    
    -- Get current location and user
    SELECT location_id, assigned_to INTO current_location_id, current_user_id
    FROM assets WHERE id = p_asset_id;
    
    -- Insert transfer record
    INSERT INTO asset_transfers (
        asset_id,
        from_location_id,
        to_location_id,
        from_user_id,
        to_user_id,
        transfer_date,
        reason,
        status,
        created_by
    ) VALUES (
        p_asset_id,
        current_location_id,
        p_to_location_id,
        current_user_id,
        p_to_user_id,
        CURDATE(),
        p_reason,
        'completed',
        p_created_by
    );
    
    -- Update asset location and assignment
    UPDATE assets 
    SET location_id = p_to_location_id,
        assigned_to = p_to_user_id,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_asset_id;
END //

DELIMITER ;
