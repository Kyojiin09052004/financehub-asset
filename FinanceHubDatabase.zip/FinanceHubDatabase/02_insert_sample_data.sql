-- Insert sample users
INSERT INTO users (username, email, password_hash, first_name, last_name, role, department) VALUES
('admin', 'admin@financehub.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'User', 'admin', 'IT'),
('jdoe', 'john.doe@financehub.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John', 'Doe', 'manager', 'Finance'),
('asmith', 'alice.smith@financehub.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Alice', 'Smith', 'accountant', 'Accounting'),
('bwilson', 'bob.wilson@financehub.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Bob', 'Wilson', 'user', 'Operations');

-- Insert asset categories
INSERT INTO asset_categories (name, description, depreciation_method, useful_life_years, salvage_value_percentage) VALUES
('Technology', 'Computers, laptops, servers, and IT equipment', 'straight_line', 3, 10.00),
('Vehicles', 'Company cars, trucks, and transportation equipment', 'declining_balance', 5, 15.00),
('Equipment', 'Manufacturing and office equipment', 'straight_line', 7, 5.00),
('Buildings', 'Real estate and building structures', 'straight_line', 25, 20.00),
('Furniture', 'Office furniture and fixtures', 'straight_line', 10, 5.00);

-- Insert locations
INSERT INTO locations (name, address, building, floor, room) VALUES
('Headquarters', '123 Business Ave, City, State 12345', 'Main Building', 'Floor 1', 'Reception'),
('Office Floor 2', '123 Business Ave, City, State 12345', 'Main Building', 'Floor 2', 'Open Office'),
('Office Floor 3', '123 Business Ave, City, State 12345', 'Main Building', 'Floor 3', 'Executive Offices'),
('Warehouse A', '456 Industrial Blvd, City, State 12345', 'Warehouse', 'Ground', 'Storage Area'),
('Parking Lot A', '123 Business Ave, City, State 12345', 'Outdoor', 'Ground', 'Parking'),
('Server Room', '123 Business Ave, City, State 12345', 'Main Building', 'Basement', 'IT-001');

-- Insert sample assets
INSERT INTO assets (asset_id, name, description, category_id, location_id, purchase_date, original_cost, current_value, accumulated_depreciation, useful_life_years, serial_number, model, manufacturer, assigned_to, created_by) VALUES
('AST-001', 'Dell OptiPlex 7090', 'Desktop computer for office use', 1, 2, '2023-01-15', 1250.00, 875.00, 375.00, 3, 'DL7090-001', 'OptiPlex 7090', 'Dell', 4, 1),
('AST-002', 'Toyota Camry 2022', 'Company vehicle for business travel', 2, 5, '2022-06-20', 28500.00, 24650.00, 3850.00, 5, 'TC2022-001', 'Camry LE', 'Toyota', 2, 1),
('AST-003', 'HP LaserJet Pro 4301', 'Office printer for document printing', 3, 2, '2023-03-10', 450.00, 385.00, 65.00, 5, 'HP4301-001', 'LaserJet Pro 4301', 'HP', NULL, 1),
('AST-004', 'MacBook Pro 16"', 'Laptop for design and development work', 1, 3, '2023-02-28', 2800.00, 2240.00, 560.00, 3, 'MBP16-001', 'MacBook Pro 16"', 'Apple', 3, 1),
('AST-005', 'Conference Table', 'Large conference table for meeting room', 5, 3, '2022-12-05', 1200.00, 1080.00, 120.00, 10, 'CT-001', 'Executive Conference Table', 'Steelcase', NULL, 1),
('AST-006', 'Ford Transit Van', 'Delivery vehicle for equipment transport', 2, 5, '2023-04-15', 35000.00, 31500.00, 3500.00, 5, 'FTV2023-001', 'Transit 250', 'Ford', 4, 1),
('AST-007', 'Dell PowerEdge R750', 'Server for data processing and storage', 1, 6, '2023-05-20', 8500.00, 7650.00, 850.00, 5, 'DPE-R750-001', 'PowerEdge R750', 'Dell', NULL, 1),
('AST-008', 'Xerox WorkCentre 6515', 'Multifunction color printer', 3, 2, '2022-11-30', 850.00, 680.00, 170.00, 5, 'XWC6515-001', 'WorkCentre 6515', 'Xerox', NULL, 1);

-- Insert depreciation records for some assets
INSERT INTO depreciation_records (asset_id, depreciation_date, depreciation_amount, accumulated_depreciation, book_value, method_used, created_by) VALUES
(1, '2023-01-31', 31.25, 31.25, 1218.75, 'straight_line', 1),
(1, '2023-02-28', 31.25, 62.50, 1187.50, 'straight_line', 1),
(1, '2023-03-31', 31.25, 93.75, 1156.25, 'straight_line', 1),
(2, '2022-06-30', 475.00, 475.00, 28025.00, 'declining_balance', 1),
(2, '2022-07-31', 475.00, 950.00, 27550.00, 'declining_balance', 1),
(2, '2022-08-31', 475.00, 1425.00, 27075.00, 'declining_balance', 1);

-- Insert sample maintenance records
INSERT INTO asset_maintenance (asset_id, maintenance_type, description, cost, maintenance_date, performed_by, status, created_by) VALUES
(2, 'routine', 'Regular oil change and inspection', 85.00, '2023-06-15', 'AutoCare Services', 'completed', 1),
(6, 'routine', 'Scheduled maintenance and tire rotation', 120.00, '2023-07-20', 'Fleet Maintenance Co.', 'completed', 1),
(7, 'inspection', 'Monthly server health check', 0.00, '2023-08-01', 'IT Department', 'completed', 1),
(1, 'repair', 'Replace faulty RAM module', 150.00, '2023-08-15', 'Tech Support', 'completed', 1);

-- Insert GL accounts for asset accounting
INSERT INTO gl_accounts (account_code, account_name, account_type) VALUES
('1000', 'Assets', 'asset'),
('1100', 'Current Assets', 'asset'),
('1200', 'Fixed Assets', 'asset'),
('1210', 'Equipment', 'asset'),
('1220', 'Vehicles', 'asset'),
('1230', 'Buildings', 'asset'),
('1240', 'Technology Assets', 'asset'),
('1250', 'Furniture & Fixtures', 'asset'),
('1300', 'Accumulated Depreciation', 'asset'),
('1310', 'Accumulated Depreciation - Equipment', 'asset'),
('1320', 'Accumulated Depreciation - Vehicles', 'asset'),
('1330', 'Accumulated Depreciation - Buildings', 'asset'),
('1340', 'Accumulated Depreciation - Technology', 'asset'),
('1350', 'Accumulated Depreciation - Furniture', 'asset'),
('6000', 'Expenses', 'expense'),
('6100', 'Depreciation Expense', 'expense'),
('6110', 'Depreciation Expense - Equipment', 'expense'),
('6120', 'Depreciation Expense - Vehicles', 'expense'),
('6130', 'Depreciation Expense - Buildings', 'expense'),
('6140', 'Depreciation Expense - Technology', 'expense'),
('6150', 'Depreciation Expense - Furniture', 'expense');

-- Update parent account relationships
UPDATE gl_accounts SET parent_account_id = 1 WHERE account_code IN ('1100', '1200', '1300');
UPDATE gl_accounts SET parent_account_id = 3 WHERE account_code IN ('1210', '1220', '1230', '1240', '1250');
UPDATE gl_accounts SET parent_account_id = 4 WHERE account_code IN ('1310', '1320', '1330', '1340', '1350');
UPDATE gl_accounts SET parent_account_id = 16 WHERE account_code IN ('6110', '6120', '6130', '6140', '6150');

-- Insert sample journal entries for asset purchases and depreciation
INSERT INTO journal_entries (entry_number, entry_date, description, total_debit, total_credit, status, created_by, posted_by, posted_at) VALUES
('JE-2023-001', '2023-01-15', 'Purchase of Dell OptiPlex 7090', 1250.00, 1250.00, 'posted', 1, 1, '2023-01-15 10:30:00'),
('JE-2023-002', '2023-01-31', 'Monthly depreciation - Technology Assets', 31.25, 31.25, 'posted', 1, 1, '2023-01-31 23:59:00'),
('JE-2023-003', '2023-02-28', 'Purchase of MacBook Pro 16"', 2800.00, 2800.00, 'posted', 1, 1, '2023-02-28 14:15:00');

-- Insert journal entry lines
INSERT INTO journal_entry_lines (journal_entry_id, account_id, description, debit_amount, credit_amount, line_number) VALUES
(1, 7, 'Technology Asset Purchase - Dell OptiPlex', 1250.00, 0.00, 1),
(1, 2, 'Cash Payment for Asset Purchase', 0.00, 1250.00, 2),
(2, 20, 'Monthly Depreciation Expense - Technology', 31.25, 0.00, 1),
(2, 13, 'Accumulated Depreciation - Technology', 0.00, 31.25, 2),
(3, 7, 'Technology Asset Purchase - MacBook Pro', 2800.00, 0.00, 1),
(3, 2, 'Cash Payment for Asset Purchase', 0.00, 2800.00, 2);
