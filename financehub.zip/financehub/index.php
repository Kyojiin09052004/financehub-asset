<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Accounting - FinanceHub Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #ff6b35;
            --primary-rgb: 255, 107, 53;
        }
        
        body {
            background-color: #ffffff;
            color: #171717;
            font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        
        .sidebar {
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-right: 1px solid #e5e7eb;
            box-shadow: 2px 0 8px rgba(0, 0, 0, 0.1);
            width: 280px;
            min-height: 100vh;
        }
        
        .nav-btn {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            width: 100%;
            padding: 0.5rem 0.75rem;
            background: transparent;
            border: none;
            color: #374151;
            border-radius: 0.375rem;
            font-size: 0.875rem;
            text-align: left;
            transition: all 0.2s ease;
            margin-bottom: 0.25rem;
        }
        
        .nav-btn:hover {
            background-color: rgba(0, 0, 0, 0.05);
            color: #111827;
        }
        
        .nav-btn.active {
            background-color: var(--primary);
            color: #ffffff;
        }
        
        .metrics-card {
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid #f3f4f6;
            border-radius: 0.5rem;
            padding: 1rem;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
        }
        
        .metrics-card:hover {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transform: translateY(-1px);
        }
        
        .chart-card {
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid #f3f4f6;
            border-radius: 0.5rem;
            padding: 1.5rem;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
        }
        
        .chart-card:hover {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transform: translateY(-1px);
        }
        
        .time-btn {
            background: transparent;
            border: 1px solid #e5e7eb;
            color: #6b7280;
            padding: 0.25rem 0.75rem;
            border-radius: 0.375rem;
            font-size: 0.875rem;
            transition: all 0.2s ease;
        }
        
        .time-btn:hover {
            background-color: rgba(0, 0, 0, 0.05);
            color: #111827;
        }
        
        .time-btn.active {
            background-color: var(--primary);
            color: #ffffff;
            border-color: var(--primary);
        }
        
        .search-input {
            background-color: rgba(255, 255, 255, 0.9);
            border: 1px solid #e5e7eb;
            color: #171717;
            border-radius: 0.375rem;
        }
        
        .search-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(var(--primary-rgb), 0.2);
            background-color: rgba(255, 255, 255, 1);
        }
        
        #chartContainer {
            position: relative;
            height: 300px;
            width: 100%;
        }

        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container-fluid p-0">
        <div class="row g-0">
            <!-- Sidebar -->
            <nav class="col-auto sidebar">
                <div class="d-flex flex-column h-100">
                    <!-- Logo -->
                    <div class="d-flex align-items-center gap-2 px-4 py-3 border-bottom">
                        <i class="bi bi-wallet2 fs-4"></i>
                        <span class="fw-bold">FinanceHub</span>
                    </div>
                    
                    <!-- Search -->
                    <div class="px-3 py-3">
                        <input type="text" class="form-control search-input" placeholder="Search assets..." id="searchInput">
                    </div>
                    
                    <!-- Navigation -->
                    <div class="flex-grow-1 px-2">
                        <button class="nav-btn">
                            <i class="bi bi-grid"></i>
                            <span>Dashboard</span>
                        </button>
                        <button class="nav-btn">
                            <i class="bi bi-journal-text"></i>
                            <span>General Ledger</span>
                        </button>
                        <button class="nav-btn">
                            <i class="bi bi-airplane"></i>
                            <span>Travel Management</span>
                        </button>
                        <button class="nav-btn">
                            <i class="bi bi-arrow-down-circle"></i>
                            <span>Accounts Receivable</span>
                        </button>
                        <button class="nav-btn">
                            <i class="bi bi-arrow-up-circle"></i>
                            <span>Accounts Payable</span>
                        </button>
                        <button class="nav-btn active">
                            <i class="bi bi-building"></i>
                            <span>Asset Accounting</span>
                        </button>
                        <button class="nav-btn">
                            <i class="bi bi-bank"></i>
                            <span>Bank Accounting</span>
                        </button>
                    </div>
                </div>
            </nav>
            
            <!-- Main Content -->
            <main class="col p-4">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="h2 mb-1 fw-bold">Asset Accounting</h1>
                        <small class="text-muted">Manage and track your company assets</small>
                    </div>
                    <button class="btn btn-primary d-flex align-items-center gap-2" onclick="addNewAsset()">
                        <i class="bi bi-plus-circle"></i>
                        Add Asset
                    </button>
                </div>
                
                <!-- Metrics Cards -->
                <div class="row g-3 mb-4" id="metricsCards">
                    <div class="col-md-6 col-lg-3">
                        <div class="metrics-card">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <small class="text-muted">Total Assets</small>
                                <i class="bi bi-building text-primary"></i>
                            </div>
                            <div>
                                <h3 class="mb-1 fw-bold" id="totalAssets"><div class="loading"></div></h3>
                                <div class="d-flex align-items-center gap-1">
                                    <small id="assetGrowth">Loading...</small>
                                    <small class="text-success" id="assetGrowthPercent"></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="metrics-card">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <small class="text-muted">Total Value</small>
                                <i class="bi bi-currency-dollar text-success"></i>
                            </div>
                            <div>
                                <h3 class="mb-1 fw-bold" id="totalValue"><div class="loading"></div></h3>
                                <div class="d-flex align-items-center gap-1">
                                    <small id="valueGrowth">Loading...</small>
                                    <small class="text-success" id="valueGrowthPercent"></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="metrics-card">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <small class="text-muted">Depreciation</small>
                                <i class="bi bi-graph-down text-danger"></i>
                            </div>
                            <div>
                                <h3 class="mb-1 fw-bold" id="totalDepreciation"><div class="loading"></div></h3>
                                <div class="d-flex align-items-center gap-1">
                                    <small id="depreciationGrowth">Loading...</small>
                                    <small class="text-danger" id="depreciationGrowthPercent"></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="metrics-card">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <small class="text-muted">Categories</small>
                                <i class="bi bi-tags text-info"></i>
                            </div>
                            <div>
                                <h3 class="mb-1 fw-bold" id="activeCategories"><div class="loading"></div></h3>
                                <div class="d-flex align-items-center gap-1">
                                    <small>Active categories</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Asset Chart -->
                <div class="chart-card mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0 fw-semibold">Asset Value & Depreciation</h5>
                        <div class="btn-group" role="group">
                            <button type="button" class="time-btn">Today</button>
                            <button type="button" class="time-btn">Last week</button>
                            <button type="button" class="time-btn active">Last month</button>
                            <button type="button" class="time-btn">Last 6 month</button>
                            <button type="button" class="time-btn">Year</button>
                        </div>
                    </div>
                    <div id="chartContainer">
                        <canvas id="assetChart"></canvas>
                    </div>
                </div>

                <!-- Asset Categories -->
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <div class="chart-card">
                            <h6 class="mb-3 fw-semibold">Asset Distribution</h6>
                            <div class="row g-2" id="assetDistribution">
                                <div class="col-12 text-center">
                                    <div class="loading"></div>
                                    <p>Loading asset distribution...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="chart-card">
                            <h6 class="mb-3 fw-semibold">Quick Actions</h6>
                            <div class="d-grid gap-2">
                                <button class="btn btn-outline-primary btn-sm d-flex align-items-center gap-2" onclick="addNewAsset()">
                                    <i class="bi bi-plus-circle"></i>
                                    Add New Asset
                                </button>
                                <button class="btn btn-outline-secondary btn-sm d-flex align-items-center gap-2" onclick="calculateDepreciation()">
                                    <i class="bi bi-calculator"></i>
                                    Calculate Depreciation
                                </button>
                                <button class="btn btn-outline-info btn-sm d-flex align-items-center gap-2" onclick="generateReport()">
                                    <i class="bi bi-file-earmark-text"></i>
                                    Generate Report
                                </button>
                                <button class="btn btn-outline-success btn-sm d-flex align-items-center gap-2" onclick="importAssets()">
                                    <i class="bi bi-upload"></i>
                                    Import Assets
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Assets Table -->
                <div class="chart-card">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0 fw-semibold">Recent Assets</h5>
                        <div class="d-flex gap-2">
                            <button class="btn btn-outline-secondary btn-sm" onclick="filterAssets()">
                                <i class="bi bi-funnel"></i>
                                Filter
                            </button>
                            <button class="btn btn-outline-secondary btn-sm" onclick="exportAssets()">
                                <i class="bi bi-download"></i>
                                Export
                            </button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Asset ID</th>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Purchase Date</th>
                                    <th>Original Cost</th>
                                    <th>Current Value</th>
                                    <th>Depreciation</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="assetsTable">
                                <tr>
                                    <td colspan="9" class="text-center">
                                        <div class="loading"></div>
                                        <p>Loading assets...</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    
    <script>
        // Global variables
        let assetChart = null;
        
        // Load dashboard data when page loads
        document.addEventListener('DOMContentLoaded', function() {
            loadDashboardMetrics();
            loadAssetCategories();
            loadRecentAssets();
            loadChartData();
            setupEventListeners();
        });

        // Load dashboard metrics
        async function loadDashboardMetrics() {
            try {
                const response = await fetch('api/dashboard_metrics.php');
                const result = await response.json();
                
                if (result.success) {
                    const data = result.data;
                    
                    // Update metrics cards
                    document.getElementById('totalAssets').textContent = data.total_assets || '0';
                    document.getElementById('totalValue').textContent = '$' + formatNumber(data.total_value || 0);
                    document.getElementById('totalDepreciation').textContent = '$' + formatNumber(data.total_depreciation || 0);
                    document.getElementById('activeCategories').textContent = data.active_categories || '0';
                    
                    // Update growth indicators
                    document.getElementById('assetGrowth').textContent = data.asset_growth || '+0 assets';
                    document.getElementById('assetGrowthPercent').textContent = data.asset_growth_percent || '+0%';
                    document.getElementById('valueGrowth').textContent = data.value_growth || '+$0';
                    document.getElementById('valueGrowthPercent').textContent = data.value_growth_percent || '+0%';
                    document.getElementById('depreciationGrowth').textContent = data.depreciation_growth || '+$0';
                    document.getElementById('depreciationGrowthPercent').textContent = data.depreciation_growth_percent || '+0%';
                }
            } catch (error) {
                console.error('Error loading dashboard metrics:', error);
                showError('Failed to load dashboard metrics');
            }
        }

        // Load asset categories distribution
        async function loadAssetCategories() {
            try {
                const response = await fetch('api/asset_categories.php');
                const result = await response.json();
                
                if (result.success) {
                    const categories = result.data;
                    const container = document.getElementById('assetDistribution');
                    
                    // Define colors for categories
                    const colors = [
                        { bg: 'rgba(59, 130, 246, 0.1)', color: '#3b82f6' },
                        { bg: 'rgba(16, 185, 129, 0.1)', color: '#10b981' },
                        { bg: 'rgba(245, 158, 11, 0.1)', color: '#f59e0b' },
                        { bg: 'rgba(139, 92, 246, 0.1)', color: '#8b5cf6' },
                        { bg: 'rgba(236, 72, 153, 0.1)', color: '#ec4899' }
                    ];
                    
                    container.innerHTML = '';
                    
                    categories.forEach((category, index) => {
                        const colorSet = colors[index % colors.length];
                        const categoryHtml = `
                            <div class="col-6">
                                <div class="d-flex align-items-center gap-2 p-2 rounded" style="background-color: ${colorSet.bg};">
                                    <div class="rounded-circle" style="width: 8px; height: 8px; background-color: ${colorSet.color};"></div>
                                    <div>
                                        <small class="text-muted d-block">${category.category_name}</small>
                                        <span class="fw-semibold">$${formatNumber(category.total_value)}</span>
                                    </div>
                                </div>
                            </div>
                        `;
                        container.innerHTML += categoryHtml;
                    });
                }
            } catch (error) {
                console.error('Error loading asset categories:', error);
                showError('Failed to load asset categories');
            }
        }

        // Load recent assets
        async function loadRecentAssets() {
            try {
                const response = await fetch('api/recent_assets.php');
                const result = await response.json();
                
                if (result.success) {
                    const assets = result.data;
                    const tbody = document.getElementById('assetsTable');
                    
                    tbody.innerHTML = '';
                    
                    assets.forEach(asset => {
                        const statusClass = asset.status === 'active' ? 'bg-success' : 'bg-secondary';
                        const icon = getCategoryIcon(asset.category_name);
                        
                        const row = `
                            <tr>
                                <td><span class="fw-medium text-primary">${asset.asset_id}</span></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="bi ${icon} text-muted"></i>
                                        <div>
                                            <div class="fw-medium">${asset.name}</div>
                                            <small class="text-muted">${asset.full_location || 'No location'}</small>
                                        </div>
                                    </div>
                                </td>
                                <td><span class="badge bg-light text-dark">${asset.category_name}</span></td>
                                <td>${formatDate(asset.purchase_date)}</td>
                                <td class="fw-medium">$${formatNumber(asset.original_cost)}</td>
                                <td class="fw-medium text-success">$${formatNumber(asset.current_value)}</td>
                                <td>
                                    <div>
                                        <span class="fw-medium text-danger">$${formatNumber(asset.accumulated_depreciation)}</span>
                                        <small class="text-muted d-block">${asset.depreciation_percent}%</small>
                                    </div>
                                </td>
                                <td><span class="badge ${statusClass}">${asset.status}</span></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-secondary" onclick="showAssetActions('${asset.asset_id}')">
                                        <i class="bi bi-three-dots"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                        tbody.innerHTML += row;
                    });
                }
            } catch (error) {
                console.error('Error loading recent assets:', error);
                showError('Failed to load recent assets');
            }
        }

        // Load chart data
        async function loadChartData() {
            try {
                const response = await fetch('api/chart_data.php');
                const result = await response.json();
                
                if (result.success) {
                    const chartData = result.data;
                    createChart(chartData);
                }
            } catch (error) {
                console.error('Error loading chart data:', error);
                showError('Failed to load chart data');
            }
        }

        // Create chart
        function createChart(data) {
            const ctx = document.getElementById('assetChart');
            if (!ctx) return;

            if (assetChart) {
                assetChart.destroy();
            }

            const config = {
                type: 'bar',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: false
                        },
                        legend: {
                            display: true,
                            position: 'top',
                            labels: {
                                color: '#374151',
                                usePointStyle: true,
                                padding: 20
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleColor: '#fff',
                            bodyColor: '#fff',
                            borderColor: '#333',
                            borderWidth: 1,
                            cornerRadius: 8,
                            callbacks: {
                                label: function(context) {
                                    const label = context.dataset.label || '';
                                    const value = context.parsed.y;
                                    return label + ': $' + formatNumber(value);
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                color: '#f3f4f6',
                                drawBorder: false
                            },
                            ticks: {
                                color: '#6b7280'
                            }
                        },
                        y: {
                            grid: {
                                color: '#f3f4f6',
                                drawBorder: false
                            },
                            ticks: {
                                color: '#6b7280',
                                callback: function(value) {
                                    return '$' + (value / 1000).toFixed(0) + 'K';
                                }
                            }
                        }
                    }
                }
            };

            assetChart = new Chart(ctx, config);
        }

        // Setup event listeners
        function setupEventListeners() {
            // Time period buttons
            const timeButtons = document.querySelectorAll('.time-btn');
            timeButtons.forEach(button => {
                button.addEventListener('click', function() {
                    timeButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    console.log('Time period selected:', this.textContent.trim());
                    // You can reload chart data here based on selected period
                });
            });

            // Search functionality
            const searchInput = document.getElementById('searchInput');
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                filterTableRows(searchTerm);
            });
        }

        // Utility functions
        function formatNumber(num) {
            if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
            } else if (num >= 1000) {
                return (num / 1000).toFixed(0) + 'K';
            }
            return parseFloat(num).toLocaleString();
        }

        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });
        }

        function getCategoryIcon(category) {
            const icons = {
                'Technology': 'bi-laptop',
                'Vehicles': 'bi-truck',
                'Equipment': 'bi-gear',
                'Buildings': 'bi-building',
                'Furniture': 'bi-house'
            };
            return icons[category] || 'bi-box';
        }

        function filterTableRows(searchTerm) {
            const rows = document.querySelectorAll('#assetsTable tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        }

        function showError(message) {
            console.error(message);
            // You can implement a toast notification here
        }

        // Action functions
        function addNewAsset() {
            alert('Add New Asset functionality - Connect to your asset form');
        }

        function calculateDepreciation() {
            alert('Calculate Depreciation functionality - Connect to your calculation logic');
        }

        function generateReport() {
            alert('Generate Report functionality - Connect to your reporting system');
        }

        function importAssets() {
            alert('Import Assets functionality - Connect to your import system');
        }

        function filterAssets() {
            alert('Filter Assets functionality - Connect to your filtering system');
        }

        function exportAssets() {
            alert('Export Assets functionality - Connect to your export system');
        }

        function showAssetActions(assetId) {
            alert('Asset actions for: ' + assetId + ' - Connect to your asset management system');
        }
    </script>
</body>
</html>
