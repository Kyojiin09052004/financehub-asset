<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

include_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Generate asset ID
    $stmt = $db->query("SELECT COUNT(*) as count FROM assets");
    $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    $asset_id = 'AST-' . str_pad($count + 1, 3, '0', STR_PAD_LEFT);
    
    $query = "INSERT INTO assets (
        asset_id, name, description, category_id, location_id, purchase_date, 
        original_cost, current_value, useful_life_years, serial_number, 
        model, manufacturer, created_by
    ) VALUES (
        :asset_id, :name, :description, :category_id, :location_id, :purchase_date,
        :original_cost, :current_value, :useful_life_years, :serial_number,
        :model, :manufacturer, 1
    )";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':asset_id', $asset_id);
    $stmt->bindParam(':name', $input['name']);
    $stmt->bindParam(':description', $input['description']);
    $stmt->bindParam(':category_id', $input['category_id']);
    $stmt->bindParam(':location_id', $input['location_id']);
    $stmt->bindParam(':purchase_date', $input['purchase_date']);
    $stmt->bindParam(':original_cost', $input['original_cost']);
    $stmt->bindParam(':current_value', $input['original_cost']); // Initially same as original cost
    $stmt->bindParam(':useful_life_years', $input['useful_life_years']);
    $stmt->bindParam(':serial_number', $input['serial_number']);
    $stmt->bindParam(':model', $input['model']);
    $stmt->bindParam(':manufacturer', $input['manufacturer']);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Asset added successfully',
            'asset_id' => $asset_id
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add asset']);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
