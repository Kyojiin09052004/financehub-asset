<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    // Get dashboard metrics
    $query = "SELECT 
        (SELECT COUNT(*) FROM assets WHERE status = 'active') AS total_assets,
        (SELECT SUM(current_value) FROM assets WHERE status = 'active') AS total_value,
        (SELECT SUM(accumulated_depreciation) FROM assets WHERE status = 'active') AS total_depreciation,
        (SELECT COUNT(DISTINCT category_id) FROM assets WHERE status = 'active') AS active_categories";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $metrics = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get growth data (mock data for now - you can implement real calculations)
    $metrics['asset_growth'] = '+23';
    $metrics['asset_growth_percent'] = '+12%';
    $metrics['value_growth'] = '+$156K';
    $metrics['value_growth_percent'] = '+8.2%';
    $metrics['depreciation_growth'] = '+$12K';
    $metrics['depreciation_growth_percent'] = '+3.1%';
    
    echo json_encode([
        'success' => true,
        'data' => $metrics
    ]);
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
