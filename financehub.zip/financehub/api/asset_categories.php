<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    // Get asset distribution by category
    $query = "SELECT 
        ac.name as category_name,
        SUM(a.current_value) as total_value,
        COUNT(a.id) as asset_count
    FROM assets a 
    JOIN asset_categories ac ON a.category_id = ac.id 
    WHERE a.status = 'active'
    GROUP BY ac.id, ac.name
    ORDER BY total_value DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $categories
    ]);
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
