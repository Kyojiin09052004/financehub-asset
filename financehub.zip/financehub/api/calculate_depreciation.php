<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    // Call the stored procedure to calculate monthly depreciation
    $target_date = date('Y-m-d');
    $stmt = $db->prepare("CALL CalculateMonthlyDepreciation(?)");
    $stmt->bindParam(1, $target_date);
    $stmt->execute();
    
    // Get updated metrics
    $metricsQuery = "SELECT 
        COUNT(*) as assets_updated,
        SUM(accumulated_depreciation) as total_depreciation_added
    FROM depreciation_records 
    WHERE depreciation_date = ?";
    
    $metricsStmt = $db->prepare($metricsQuery);
    $metricsStmt->bindParam(1, $target_date);
    $metricsStmt->execute();
    $metrics = $metricsStmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'message' => 'Depreciation calculated successfully',
        'data' => $metrics
    ]);
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
