<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    // Get recent assets
    $query = "SELECT 
        a.asset_id,
        a.name,
        a.description,
        ac.name as category_name,
        l.name as location_name,
        CONCAT(l.building, ' - ', l.floor, ' - ', l.room) as full_location,
        a.purchase_date,
        a.original_cost,
        a.current_value,
        a.accumulated_depreciation,
        a.status,
        a.model,
        a.manufacturer,
        ROUND((a.accumulated_depreciation / a.original_cost) * 100, 1) as depreciation_percent
    FROM assets a 
    LEFT JOIN asset_categories ac ON a.category_id = ac.id 
    LEFT JOIN locations l ON a.location_id = l.id
    ORDER BY a.created_at DESC
    LIMIT 10";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $assets
    ]);
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
