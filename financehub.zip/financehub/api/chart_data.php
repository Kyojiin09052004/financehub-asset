<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

try {
    // Get chart data for asset values and depreciation by category
    $query = "SELECT 
        ac.name as category_name,
        SUM(a.current_value) as asset_value,
        SUM(a.accumulated_depreciation) as depreciation_value
    FROM assets a 
    JOIN asset_categories ac ON a.category_id = ac.id 
    WHERE a.status = 'active'
    GROUP BY ac.id, ac.name
    ORDER BY asset_value DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format data for Chart.js
    $labels = [];
    $assetValues = [];
    $depreciationValues = [];
    
    foreach($data as $row) {
        $labels[] = $row['category_name'];
        $assetValues[] = floatval($row['asset_value']);
        $depreciationValues[] = floatval($row['depreciation_value']);
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'labels' => $labels,
            'datasets' => [
                [
                    'label' => 'Asset Value',
                    'data' => $assetValues,
                    'backgroundColor' => '#3b82f6',
                    'borderColor' => '#3b82f6',
                    'borderWidth' => 1
                ],
                [
                    'label' => 'Depreciation',
                    'data' => $depreciationValues,
                    'backgroundColor' => '#ef4444',
                    'borderColor' => '#ef4444',
                    'borderWidth' => 1
                ]
            ]
        ]
    ]);
    
} catch(Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
